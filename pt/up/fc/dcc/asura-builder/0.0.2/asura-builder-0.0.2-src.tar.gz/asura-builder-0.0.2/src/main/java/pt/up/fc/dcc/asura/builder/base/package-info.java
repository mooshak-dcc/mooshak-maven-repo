/*
  WARNING: DO NOT CHANGE THE CONTENTS OF THIS PACKAGE!
 */
/**
 * Game barebones to implement other types of games
 *
 * @author José Paulo Leal <code>zp@dcc.fc.up.pt</code>
 * @author José Carlos Paiva <code>josepaiva94@gmail.com</code>
 */
package pt.up.fc.dcc.asura.builder.base;