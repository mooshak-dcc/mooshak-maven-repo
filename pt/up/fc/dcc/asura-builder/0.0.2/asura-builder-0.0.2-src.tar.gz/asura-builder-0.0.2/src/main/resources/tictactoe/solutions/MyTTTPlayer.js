// ------------------------ Skeleton --------------------------------

load('tictactoe/wrappers/js/TicTacToePlayer.js');

(function (exports) {'use strict';

    /**
     * Naive player of Tic-Tac-Toe Just chooses a free position. Assumes that valid
     * moves are positive digits and 0 is a NOP.
     *
     * @author José Carlos Paiva <code>josepaiva94@gmail.com</code>
     */
    function MyTTTPlayer() {
        GamePlayerWrapper.call(this);
    }

    MyTTTPlayer.prototype = Object.create(GamePlayerWrapper.prototype);

    // ---------------------- Your code below ---------------------------

    /**
     * Get the name of the player
     *
     * @returns {string} name of the player
     */
    MyTTTPlayer.prototype.getName = function () {
        return 'Professor X';
    };

    /**
     * Initialize the player
     */
    MyTTTPlayer.prototype.init = function () {
    };

    /**
     * Execute player action
     */
    MyTTTPlayer.prototype.execute = function () {
        this.play(this.generateMove());
    };

    /**
     * Generates randomly a valid move
     *
     * @returns {number} a valid move
     */
    MyTTTPlayer.prototype.generateMove = function () {

        var possibleMoves = [];

        var i = 1;
        while (i <= 9) {
            if (this.isFree(i))
                possibleMoves.push(i);
            i++;
        }

        if (possibleMoves.length === 0)
            return 0;

        return possibleMoves[getRandomInt(possibleMoves.length)];
    };

    /**
     * Get a random int between 0 and max
     *
     * @param max {number} upper limit
     * @returns {number} random int between 0 and max
     */
    function getRandomInt(max) {
        return Math.floor(Math.random() * Math.floor(max));
    }

    // ------------------------ Skeleton --------------------------------

    // will export everywhere the `method` function
    exports.Player = MyTTTPlayer;
}(this));
