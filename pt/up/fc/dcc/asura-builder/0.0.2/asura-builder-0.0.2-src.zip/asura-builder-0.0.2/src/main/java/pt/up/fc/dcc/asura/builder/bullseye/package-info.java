/**
 * Bullseye shooting game
 *
 * @author José Carlos Paiva <code>josepaiva94@gmail.com</code>
 */
package pt.up.fc.dcc.asura.builder.bullseye;