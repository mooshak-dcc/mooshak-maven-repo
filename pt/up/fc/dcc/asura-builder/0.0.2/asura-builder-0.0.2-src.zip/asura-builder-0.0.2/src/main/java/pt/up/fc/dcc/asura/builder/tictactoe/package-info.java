/**
 * Tic Tac Toe game implementation
 *
 * @author José Paulo Leal <code>zp@dcc.fc.up.pt</code>
 * @author José Carlos Paiva <code>josepaiva94@gmail.com</code>
 */
package pt.up.fc.dcc.asura.builder.tictactoe;