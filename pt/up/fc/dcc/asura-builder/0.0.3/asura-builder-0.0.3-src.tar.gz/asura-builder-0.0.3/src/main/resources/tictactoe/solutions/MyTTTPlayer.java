
import tictactoe.wrappers.java.TicTacToePlayer;

import java.util.List;
import java.util.ArrayList;
import java.util.Random;

/**
 * Naive player of Tic-Tac-Toe Just chooses a free position. Assumes that valid
 * moves are positive digits and 0 is a NOP.
 *
 * @author José Paulo Leal <code>zp@dcc.fc.up.pt</code>
 * @author José Carlos Paiva <code>josepaiva94@gmail.com</code>
 */
public class MyTTTPlayer extends TicTacToePlayer {

    Random random = null;

    @Override
    public String getName() {
        return "Random";
    }

    @Override
    public void init() {
        random = new Random();
    }

    @Override
    public void execute() {
        play(generateMove());
    }

    /**
     * Generate a position to play the piece
     *
     * @return position to play the piece
     */
    int generateMove() {
        List<Integer> possibleMoves = new ArrayList<Integer>();

        for (int i = 1; i <= 9; i++)
            if (isFree(i))
                possibleMoves.add(i);

        if (possibleMoves.isEmpty())
            return 0;

        return possibleMoves.get(random.nextInt(possibleMoves.size()));
    }
}
